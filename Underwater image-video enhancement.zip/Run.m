%%              * _ * _UNDERATEER_IMAGE_ENHANCEMENT * _ *
                      % code written by "Rahul_khoond"
%% paper title "colour balancing with average filtering and principle component analysis for underwater image/video enhancement"
% please cite the above paper if you find these code helpful
% feel free to contact: rahulkhoond@gmail.com

%%
clc;
clear all;
close all;

addpath MFILES
img = imread('1.jpg');
%figure, imshow(img);
img1 = SimplestColorBalance(img);
% imwrite(img1,'F:\RAHUL_KHOOND\F\2021_underater\diag/colorbalanced.tif');
% figure,imshow(img)
 %figure,imshow(img1);

%%        RGB TO YUV ( Intensity, color blue and green )
%[R G B] = imsplit(img1);
R=img1(:,:,1);
G=img1(:,:,2);
B=img1(:,:,3);
% subplot(2,2,1); imshow(r);
% subplot(2,2,2); imshow(g);
% subplot(2,2,3); imshow(b);

    R = double(R);
    G = double(G);
    B = double(B);
    
    Y =  0.257 * R + 0.504 * G + 0.098 * B +  16;
    U = -0.148 * R - 0.291 * G + 0.439 * B + 128;
    V =  0.439 * R - 0.368 * G - 0.071 * B + 128;
    
    Y = uint8(Y);
    U = uint8(U);
    V = uint8(V);
%  imwrite(Y,'F:\RAHUL_KHOOND\F\2021_underater\diag/Y.tif');
%  imwrite(U,'F:\RAHUL_KHOOND\F\2021_underater\diag/U.tif');
%  imwrite(V,'F:\RAHUL_KHOOND\F\2021_underater\diag/V.tif');
% subplot(2,2,1); imshow(Y);
% subplot(2,2,2); imshow(U);
% subplot(2,2,3); imshow(V);

%%    AVERAGE _ FILTER _ ON Y
  M=35;
h=1/(M*M)*ones(M);
d1=imfilter(double(Y),double(h),'circular');
b1=double(Y)-d1; 
y1 = mat2gray(d1);
y2 = mat2gray(b1);

% imwrite(y1,'F:\RAHUL_KHOOND\F\2021_underater\diag/Detail.tif');
% imwrite(y2,'F:\RAHUL_KHOOND\F\2021_underater\diag/Base.tif');
% figure,imshow(y1);
% figure,imshow(y2);

% y11 = adapthisteq(y1);
% y22 = adapthisteq(y2);

y11 = histeq(y1);
y22 = histeq(y2);

% imwrite(y11,'F:\RAHUL_KHOOND\F\2021_underater\diag/Heq detail.tif');
% imwrite(y22,'F:\RAHUL_KHOOND\F\2021_underater\diag/Heq Base.tif');
% figure,imshow(y11);
% figure,imshow(y22);
%%
X1=y11(:)';
X2=y22(:)';
X=[X1 X2];
C=cov(X1,X2);
[e,f] = eig(C);
diagD=diag(f);
if diagD(1)>diagD(2)
    V1=e(:,1);                 % pca based fusion 
else
    V1=e(:,2);
end

w1=V1(1)/(V1(1)+V1(2));
w2=V1(2)/(V1(1)+V1(2));

yy1=w1*y11+w2*y22;
% figure, imshow(yy1);
% imwrite(yy1,'F:\RAHUL_KHOOND\F\2021_underater\diag/PCA fuse baseD.tif');

%%
% yy = (y11 + y22)/2;
% yy1 = mat2gray(yy);
%figure,imshow(yy1);

%%    yuv to rgb 

    yy1 = double(Y) -  16;
    U = double(U) - 128;
    V = double(V) - 128;
    R = 1.164 * yy1             + 1.596 * V;
    G = 1.164 * yy1 - 0.392 * U - 0.813 * V;
    B = 1.164 * yy1 + 2.017 * U;
    
    yuv = cat(3,yy1,U,V);
% imwrite(yuv,'F:\RAHUL_KHOOND\F\2021_underater\diag/Fyuv.tif');
%  figure, imshow(R);
%  figure, imshow(G);
%  figure, imshow(B);
 
    R = mat2gray(R);
    G = mat2gray(G);
    B = mat2gray(B);
%     figure, imshow(R);
%  figure, imshow(G);
%  figure, imshow(B);
  K = im2double(img);
O = cat(3,R,G,B);
figure, imshow(O);
%oo= histeq(O);
%figure, imshow(oo);
I = [ K O];
figure, imshow(I);title('input and output');



% xx= entropy(O)

% imwrite(K ,'F:\2021_underater\Image Despeckle Filtering (IDF)\Images/in_7.tif');
%imwrite(O,'F:\RAHUL_KHOOND\F\2021_underater\Image Despeckle Filtering (IDF)\Images/out_4.tif');
% imwrite(img,'F:\RAHUL_KHOOND\F\2021_underater\diag/inp_11.tif');
%%

